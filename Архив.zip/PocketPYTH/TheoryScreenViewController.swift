//
//  TheoryScreenViewController.swift
//  PocketPYTH
//
//  Created by Владислав on 16.10.2021.
//

import UIKit

class TheoryScreenViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func goBackMenu(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
}
